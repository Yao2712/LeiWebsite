Place your images here for the manga page.

Required filenames (used by the site):
- bg.jpg         -> background image (wide banner). Used by `assets/css/style.css` as the page background.
- poster.jpg     -> poster / cover image used on the manga page `与你编缀的泡沫.html`.

Optional: if you prefer to use the existing cover referenced in `home libary.html`, place a copy named:
- 与你编缀的泡沫封面.jpg

Save the poster (vertical image) as `poster.jpg` and the banner as `bg.jpg` in this folder.

Example paths:
assets/img/poster.jpg
assets/img/bg.jpg
